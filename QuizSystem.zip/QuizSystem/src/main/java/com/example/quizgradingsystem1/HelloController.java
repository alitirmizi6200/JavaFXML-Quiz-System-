package com.example.quizgradingsystem1;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;

import java.io.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

import static java.lang.Integer.parseInt;

public class HelloController {

    // AHMAD ASHOOR and 101136881 of all group 52
    @FXML
    private Label welcomeText;
    @FXML
    private Button StartQuiz;
    @FXML
    private Label Q1;
    @FXML
    private RadioButton Q1a;
    @FXML
    private RadioButton Q1b;
    @FXML
    private RadioButton Q1c;
    @FXML
    private RadioButton Q1d;
    @FXML
    private Label Q2;
    @FXML
    private RadioButton Q2a;
    @FXML
    private RadioButton Q2b;
    @FXML
    private RadioButton Q2c;
    @FXML
    private RadioButton Q2d;
    @FXML
    private Label Q3;
    @FXML
    private RadioButton Q3a;
    @FXML
    private RadioButton Q3b;
    @FXML
    private RadioButton Q3c;
    @FXML
    private RadioButton Q3d;
    @FXML
    private Label Q4;
    @FXML
    private RadioButton Q4a;
    @FXML
    private RadioButton Q4b;
    @FXML
    private RadioButton Q4c;
    @FXML
    private RadioButton Q4d;
    @FXML
    private Label Q5;
    @FXML
    private RadioButton Q5a;
    @FXML
    private RadioButton Q5b;
    @FXML
    private RadioButton Q5c;
    @FXML
    private RadioButton Q5d;
    @FXML
    private Label CalGradeLable;

    @FXML
    private TextField name;

    @FXML
    private Label Error;
    @FXML
    private Label avgGrade;
    String[][] str1 = new String[5][6];
    int[] random_list = new int[5];
    String line;

    String[] AnsStr = new String[5];
    public void display(){

        StartQuiz.setDisable(true);
        welcomeText.setText(" ");
        for(int i=0; i<5;i++) {


            int randomNum = ThreadLocalRandom.current().nextInt(1, 20 );
            Lable:
            // Error check
            for(int j=0; j<=i;j++) {
                if(randomNum == random_list[j] ){
                    randomNum = ThreadLocalRandom.current().nextInt(1, 20 );
                   continue Lable;
                }
            }
            random_list[i] = randomNum;

        }

        for(int h=0; h<5; h++ ) {
            int n = random_list[h]; // The line number

            File filename = new File("exam");
            filename.setWritable(true);
            try (BufferedReader br = new BufferedReader(new FileReader(filename.getAbsolutePath()))) {
                for (int i = 0; i < n; i++)
                    br.readLine();
                line = br.readLine();

            } catch (IOException e) {
                System.out.println(e);
            }
            String[] output = line.split("#");
            str1[h][0] =output[0];
            str1[h][1] =output[1];
            str1[h][2] =output[2];
            str1[h][3] =output[3];
            str1[h][4] =output[4];
            str1[h][5] =output[5];
        }

        Q1.setText(str1[0][0]);
        Q2.setText(str1[1][0]);
        Q3.setText(str1[2][0]);
        Q4.setText(str1[3][0]);
        Q5.setText(str1[4][0]);

        Q1a.setText(str1[0][1]);
        Q2a.setText(str1[1][1]);
        Q3a.setText(str1[2][1]);
        Q4a.setText(str1[3][1]);
        Q5a.setText(str1[4][1]);

        Q1b.setText(str1[0][2]);
        Q2b.setText(str1[1][2]);
        Q3b.setText(str1[2][2]);
        Q4b.setText(str1[3][2]);
        Q5b.setText(str1[4][2]);

        Q1c.setText(str1[0][3]);
        Q2c.setText(str1[1][3]);
        Q3c.setText(str1[2][3]);
        Q4c.setText(str1[3][3]);
        Q5c.setText(str1[4][3]);

        Q1d.setText(str1[0][4]);
        Q2d.setText(str1[1][4]);
        Q3d.setText(str1[2][4]);
        Q4d.setText(str1[3][4]);
        Q5d.setText(str1[4][4]);


    }

    public void Answer(){
        AnsStr[0]= "X";
        AnsStr[1]= "X";
        AnsStr[2]= "X";
        AnsStr[3]= "X";
        AnsStr[4]= "X";


        if(Q1a.isSelected()){ AnsStr[0] = str1[0][1]; }
        else if(Q1b.isSelected()){ AnsStr[0] = str1[0][2]; }
        else if(Q1c.isSelected()){ AnsStr[0] = str1[0][3]; }
        else if(Q1d.isSelected()){ AnsStr[0] = str1[0][4]; }

        if(Q2a.isSelected()){ AnsStr[1] = str1[1][1]; }
        else if(Q2b.isSelected()){ AnsStr[1] = str1[1][2]; }
        else if(Q2c.isSelected()){ AnsStr[1] = str1[1][3]; }
        else if(Q2d.isSelected()){ AnsStr[1] = str1[1][4]; }

        if(Q3a.isSelected()){ AnsStr[2] = str1[2][1]; }
        else if(Q3b.isSelected()){ AnsStr[2] = str1[2][2]; }
        else if(Q3c.isSelected()){ AnsStr[2] = str1[2][3]; }
        else if(Q3d.isSelected()){ AnsStr[2] = str1[2][4]; }

        if(Q4a.isSelected()){ AnsStr[3] = str1[3][1]; }
        else if(Q4b.isSelected()){ AnsStr[3] = str1[3][2]; }
        else if(Q4c.isSelected()){ AnsStr[3] = str1[3][3]; }
        else if(Q4d.isSelected()){ AnsStr[3] = str1[3][4]; }

        if(Q5a.isSelected()){ AnsStr[4] = str1[4][1]; }
        else if(Q5b.isSelected()){ AnsStr[4] = str1[4][2]; }
        else if(Q5c.isSelected()){ AnsStr[4] = str1[4][3]; }
        else if(Q5d.isSelected()){ AnsStr[4] = str1[4][4]; }


    }


    int grade = 0;
    public void Grade(){
        grade = 0;
        try {

            if (AnsStr[0].equals(str1[0][5])) {
                grade = grade + 20;
            }
             if (AnsStr[1].equals(str1[1][5])) {
                grade = grade + 20;
            }
             if (AnsStr[2].equals(str1[2][5])) {
                grade = grade + 20;
            }
             if (AnsStr[3].equals(str1[3][5]) ) {
                grade = grade + 20;
            }
             if (AnsStr[4].equals(str1[4][5])  ) {
                grade = grade + 20;
            }
            System.out.println(grade);
             if (AnsStr[0]== "X"|| AnsStr[0].equals(str1[0][5] )) {}
             else {grade = grade - 5;}
             if (AnsStr[1]== "X"|| AnsStr[1].equals(str1[1][5] )) {}
             else {grade = grade - 5;}
             if (AnsStr[2]== "X"|| AnsStr[2].equals(str1[2][5] )) {}
             else {grade = grade - 5;}
             if (AnsStr[3]== "X"|| AnsStr[3].equals(str1[3][5] )) {}
             else {grade = grade - 5;}
             if (AnsStr[4]== "X"|| AnsStr[4].equals(str1[4][5]))  {}
             else {grade = grade - 5;}


            CalGradeLable.setText(grade + " / 100");
        }
        catch (Exception e){
            CalGradeLable.setText("Quiz not attempted");

        }
    }




    public void Submit() throws IOException {

        if (name.getText().isEmpty()) {
            Error.setText("Name Field cannot be Empty");
        }
        else{
            try {
                File f = new File("result.txt");
                f.setWritable(true);
                PrintWriter out = new PrintWriter(new BufferedWriter(new FileWriter(f.getAbsolutePath(), true)));
                out.println(name.getText() +" #"+ Arrays.toString(AnsStr)+" #"+ grade);
                out.close();
            } catch (IOException e) {
                System.out.println(e.toString());
            }
            Q1a.setDisable(true);
            Q2a.setDisable(true);
            Q3a.setDisable(true);
            Q4a.setDisable(true);
            Q5a.setDisable(true);

            Q1b.setDisable(true);
            Q2b.setDisable(true);
            Q3b.setDisable(true);
            Q4b.setDisable(true);
            Q5b.setDisable(true);

            Q1c.setDisable(true);
            Q2c.setDisable(true);
            Q3c.setDisable(true);
            Q4c.setDisable(true);
            Q5c.setDisable(true);

            Q1d.setDisable(true);
            Q2d.setDisable(true);
            Q3d.setDisable(true);
            Q4d.setDisable(true);
            Q5d.setDisable(true);


        }
    }
    int avg = 0;
    int count = 0;
    public void AvgGrade(){

        File filename = new File("result.txt");

        try (BufferedReader br = new BufferedReader(new FileReader(filename.getAbsolutePath()))){

            while((line = br.readLine())!=null){
                String[] output = line.split("#");
                avg = avg+parseInt(output[2]);
                count = count +1;
            }

        } catch (Exception e) {
            System.out.println(e);
        }
        if(count == 0){count++;}
        avg = avg/count;
        avgGrade.setText(avg+" ");
    }


}